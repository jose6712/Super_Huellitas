function saludo() {
    alert("¡Hola! todo funciona correctamente 🐶🐱 te amo mucho" );
}
